
public class Cuenta {
	private double saldo;
	
	public Cuenta() {
		this.saldo = 0.0;
	}

	public Double getSaldo(){
		return this.saldo;
	}
	
	public void setSaldo(double cantidad) {
		this.saldo = cantidad;		
	}

	public void ingresar(double cantidad) {
		if(validarIngreso(cantidad)) {
			this.saldo += cantidad;
		}
	}	
	
	public void retirar(double cantidad) {
		if(validarRetirada(cantidad)){
			this.saldo -= cantidad;
		}
	}	
	
	public void transfiere(Cuenta cuenta2, double cantidad) {
		if (validarTransferencia(cantidad)){
			this.retirar(cantidad);
			cuenta2.ingresar(cantidad);
		}
	}
	
	private boolean validarIngreso(double cantidad) {
		if(((double)Math.round(cantidad * 100d) / 100d == cantidad) &&
				(cantidad > 0) &&
				(cantidad <= 6000.00)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean validarRetirada(double cantidad) {
		if(((double)Math.round(cantidad * 100d) / 100d == cantidad) &&
				(cantidad >	0) &&
				(cantidad <= 6000.00) &&
				(cantidad < this.saldo)) {
			return true;
		} else {
			return false;
		}
	}	
	
	private boolean validarTransferencia(double cantidad) {
		if(((double)Math.round(cantidad * 100d) / 100d == cantidad) &&
				(cantidad > 0) &&
				(cantidad <= 3000.00)) {
			return true;
		} else {
			return false;
		}
	}	

	

	
	
	
}